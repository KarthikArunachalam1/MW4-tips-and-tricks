# MW4 Tips (Android)

Open this folder in Android Studio, let Gradle sync, then Run on a phone or emulator. (Not compiled or tested by Claude.)

## 1. Content feed (keeps content updating)
Host `app/src/main/assets/feed.json` at a public URL (e.g. a GitHub raw link) and set `FEED_URL` in `Feed.kt`.
The app checks it about every 6 hours. Add a tip with a new `id` to publish it. Set `"advantage": true` for a competitive edge.
For a video moment, use a link like `https://www.youtube.com/watch?v=VIDEOID&t=205s` (205s = 3:25).

## 2. Popup
New tips flagged `advantage: true` appear as a heads-up notification. Allow notifications when asked.

## 3. Email (free, no server)
Android apps can't send email silently, so the app calls a small Google Apps Script that emails you.
1. Go to script.google.com, New project, paste:

    function doPost(e) {
      var d = JSON.parse(e.postData.contents);
      if (!/^[^@\s]+@gmail\.com$/.test(d.to)) return ContentService.createTextOutput("bad");
      MailApp.sendEmail(d.to, d.subject, d.body);
      return ContentService.createTextOutput("ok");
    }

2. Deploy > New deployment > Web app > Execute as: Me, Access: Anyone. Copy the URL.
3. Paste it into `WEBHOOK_URL` in `Feed.kt`.
