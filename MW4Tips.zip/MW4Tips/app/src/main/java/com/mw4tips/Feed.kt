package com.mw4tips

import android.content.Context
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

const val FEED_URL = "https://raw.githubusercontent.com/KarthikArunachalam1/MW4-tips-and-tricks/main/feed.json"
// Optional: Google Apps Script web app URL that sends the email (see README.md).
const val WEBHOOK_URL = ""

data class Tip(val id: String, val title: String, val category: String, val advantage: Boolean,
               val added: String, val source: String, val overview: String, val why: String,
               val how: String, val nav: String, val video: String)

object Feed {
    fun download(): String {
        val c = URL(FEED_URL).openConnection() as HttpURLConnection
        c.connectTimeout = 10000; c.readTimeout = 10000
        return c.inputStream.bufferedReader().use { it.readText() }
    }

    fun parse(txt: String): List<Tip> {
        val a = JSONObject(txt).getJSONArray("tips")
        return (0 until a.length()).map {
            val o = a.getJSONObject(it)
            Tip(o.getString("id"), o.getString("title"), o.optString("category", "General"),
                o.optBoolean("advantage", false), o.optString("added", ""), o.optString("source", ""),
                o.optString("overview", o.optString("body", "")), o.optString("why", ""),
                o.optString("how", ""), o.optString("nav", ""), o.optString("video", ""))
        }.sortedByDescending { it.added }   // newest update first
    }

    private fun ver(t: String) = try { JSONObject(t).optInt("version", 0) } catch (e: Exception) { 0 }

    // Uses the downloaded feed unless the bundled one is newer.
    fun load(ctx: Context): List<Tip> {
        val bundled = ctx.assets.open("feed.json").bufferedReader().use { it.readText() }
        val cached = ctx.getSharedPreferences("mw4", 0).getString("feed", null)
        val txt = if (cached != null && ver(cached) >= ver(bundled)) cached else bundled
        return parse(txt)
    }
}
