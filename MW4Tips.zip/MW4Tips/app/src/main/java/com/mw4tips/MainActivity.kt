package com.mw4tips

import android.Manifest
import android.accounts.AccountManager
import android.content.Intent
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.animation.core.tween
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CutCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.work.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.concurrent.TimeUnit

// ---- Warzone-style look: dark panels, hazard-yellow accent, angled corners, condensed caps ----
val Cond = FontFamily(Typeface.create("sans-serif-condensed", Typeface.BOLD))
val Yellow = Color(0xFFF2C200)
val Bg = Color(0xFF0B0C0E)
val Panel = Color(0xFF16181B)
val Panel2 = Color(0xFF1F2226)
val Muted = Color(0xFF9AA0A6)
val Soft = Color(0xFFD7DADD)
val Cut = CutCornerShape(topStart = 0.dp, topEnd = 14.dp, bottomEnd = 0.dp, bottomStart = 14.dp)
val CutSmall = CutCornerShape(topStart = 0.dp, topEnd = 8.dp, bottomEnd = 0.dp, bottomStart = 8.dp)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        val req = PeriodicWorkRequestBuilder<UpdateWorker>(6, TimeUnit.HOURS)
            .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build()).build()
        WorkManager.getInstance(this).enqueueUniquePeriodicWork("feed", ExistingPeriodicWorkPolicy.KEEP, req)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(primary = Yellow, onPrimary = Color.Black,
                background = Bg, surface = Panel, onSurface = Color.White, onBackground = Color.White)) { Root() }
        }
    }
}

@Composable
fun rememberTick(): (Boolean) -> Unit {
    val h = LocalHapticFeedback.current
    return remember(h) {
        { strong: Boolean ->
            h.performHapticFeedback(if (strong) HapticFeedbackType.LongPress else HapticFeedbackType.TextHandleMove)
        }
    }
}

@Composable
fun WzButton(text: String, modifier: Modifier = Modifier, filled: Boolean = true, onClick: () -> Unit) {
    val tick = rememberTick()
    Button(
        onClick = { tick(true); onClick() }, shape = CutSmall, modifier = modifier,
        colors = ButtonDefaults.buttonColors(
            containerColor = if (filled) Yellow else Panel2,
            contentColor = if (filled) Color.Black else Color.White)
    ) { Text(text.uppercase(), fontFamily = Cond, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp) }
}

@Composable
fun Root() {
    val ctx = LocalContext.current
    val prefs = ctx.getSharedPreferences("mw4", 0)
    var stage by remember { mutableStateOf(0) }
    Surface(Modifier.fillMaxSize(), color = Bg) {
        Crossfade(targetState = stage, animationSpec = tween(450), label = "stage") { s ->
            when (s) {
                0 -> Splash { stage = if (prefs.getBoolean("onboarded", false)) 2 else 1 }
                1 -> Welcome { email ->
                    prefs.edit().putBoolean("onboarded", true).putString("email", email).apply()
                    stage = 2
                }
                else -> Screen()
            }
        }
    }
}

@Composable
fun Splash(onStart: () -> Unit) {
    var show by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { show = true }
    Column(Modifier.fillMaxSize().padding(28.dp), verticalArrangement = Arrangement.Center) {
        AnimatedVisibility(
            visible = show,
            enter = fadeIn(tween(700)) + slideInVertically(animationSpec = tween(700), initialOffsetY = { it / 5 })
        ) {
            Column {
                Text("WARZONE TIPS AND UPDATES", fontFamily = Cond, fontWeight = FontWeight.Black,
                    fontSize = 38.sp, lineHeight = 40.sp, color = Color.White)
                Spacer(Modifier.height(10.dp))
                Box(Modifier.width(80.dp).height(4.dp).background(Yellow))
                Spacer(Modifier.height(24.dp))
                Text("Vanga pangalingala.. Tips and tricks la update aagite irukum app la.. paathukathukongada botu pasangala",
                    color = Soft, fontSize = 17.sp, lineHeight = 24.sp)
                Spacer(Modifier.height(32.dp))
                WzButton("Let's go", Modifier.fillMaxWidth().height(52.dp), onClick = onStart)
                Spacer(Modifier.height(24.dp))
                Text("DISCLAIMER: ALL CONTENT IN THIS APP IS IN ENGLISH.", color = Muted,
                    fontSize = 11.sp, letterSpacing = 1.sp)
            }
        }
    }
}

@Composable
fun Welcome(onDone: (String) -> Unit) {
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val name = r.data?.getStringExtra(AccountManager.KEY_ACCOUNT_NAME)
        if (!name.isNullOrBlank()) onDone(name)
    }
    Column(Modifier.fillMaxSize().padding(28.dp), verticalArrangement = Arrangement.Center) {
        Text("SIGN IN", fontFamily = Cond, fontWeight = FontWeight.Black, fontSize = 34.sp, color = Color.White)
        Spacer(Modifier.height(10.dp))
        Box(Modifier.width(80.dp).height(4.dp).background(Yellow))
        Spacer(Modifier.height(20.dp))
        Text("Sign in with your Google account to get an email when a new competitive edge appears. You can skip and still get pop-up alerts.",
            color = Soft, fontSize = 16.sp, lineHeight = 23.sp)
        Spacer(Modifier.height(28.dp))
        WzButton("Continue with Google", Modifier.fillMaxWidth().height(52.dp)) {
            launcher.launch(AccountManager.newChooseAccountIntent(null, null, arrayOf("com.google"), null, null, null, null))
        }
        Spacer(Modifier.height(10.dp))
        WzButton("Skip", Modifier.fillMaxWidth().height(52.dp), filled = false) { onDone("") }
    }
}

@Composable
fun Section(label: String, text: String) {
    if (text.isBlank()) return
    Spacer(Modifier.height(12.dp))
    Text(label, color = Yellow, fontFamily = Cond, fontWeight = FontWeight.Bold, fontSize = 12.sp, letterSpacing = 2.sp)
    Spacer(Modifier.height(2.dp))
    Text(text, color = Soft, fontSize = 15.sp, lineHeight = 21.sp)
}

@Composable
fun TipCard(t: Tip) {
    val ctx = LocalContext.current
    val tick = rememberTick()
    var open by remember(t.id) { mutableStateOf(false) }
    val bar = if (t.advantage) Yellow else Color(0xFF3A3F45)
    Column(
        Modifier.fillMaxWidth().animateContentSize().clip(Cut).background(Panel)
            .drawBehind { drawRect(bar, size = Size(5.dp.toPx(), size.height)) }
            .clickable { tick(false); open = !open }
            .padding(start = 21.dp, top = 16.dp, end = 16.dp, bottom = 16.dp)
    ) {
        Text(t.category.uppercase() + (if (t.advantage) "  •  COMPETITIVE EDGE" else "") +
            (if (t.added.isNotBlank()) "  •  " + t.added else ""),
            color = if (t.advantage) Yellow else Muted, fontFamily = Cond, fontSize = 11.sp, letterSpacing = 1.5.sp)
        Spacer(Modifier.height(4.dp))
        Text(t.title.uppercase(), color = Color.White, fontFamily = Cond, fontWeight = FontWeight.Black,
            fontSize = 21.sp, lineHeight = 25.sp)
        if (t.source.isNotBlank()) {
            Spacer(Modifier.height(2.dp))
            Text("SOURCE: " + t.source, color = Muted, fontSize = 11.sp, letterSpacing = 0.5.sp)
        }
        Section("OVERVIEW", t.overview)
        if (open) {
            Section("WHY", t.why)
            Section("HOW", t.how)
            if (t.nav.isNotBlank()) {
                Spacer(Modifier.height(12.dp))
                Column(Modifier.fillMaxWidth().clip(CutSmall).background(Panel2).padding(12.dp)) {
                    Text("NAVIGATION", color = Yellow, fontFamily = Cond, fontWeight = FontWeight.Bold,
                        fontSize = 12.sp, letterSpacing = 2.sp)
                    Spacer(Modifier.height(4.dp))
                    Text(t.nav, color = Color.White, fontFamily = FontFamily.Monospace, fontSize = 13.sp, lineHeight = 19.sp)
                }
            }
            if (t.video.isNotBlank()) {
                Spacer(Modifier.height(14.dp))
                WzButton(if (t.video.contains("youtu")) "Watch video" else "Read full update", Modifier.fillMaxWidth().height(46.dp)) {
                    ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(t.video)))
                }
            }
        } else {
            Spacer(Modifier.height(10.dp))
            Text("TAP TO EXPAND  +", color = Yellow, fontFamily = Cond, fontSize = 12.sp, letterSpacing = 2.sp)
        }
    }
}

@Composable
fun Screen() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val tick = rememberTick()
    var tips by remember { mutableStateOf(Feed.load(ctx)) }
    var msg by remember { mutableStateOf("") }
    var filter by remember { mutableStateOf("ALL") }
    val cats = listOf("ALL", "COMPETITIVE EDGE") + tips.map { it.category.uppercase() }.distinct()
    val shown = tips.filter {
        when (filter) {
            "ALL" -> true
            "COMPETITIVE EDGE" -> it.advantage
            else -> it.category.uppercase() == filter
        }
    }
    Column(Modifier.fillMaxSize().background(Bg)) {
        Row(Modifier.fillMaxWidth().padding(start = 16.dp, end = 8.dp, top = 12.dp), verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("WARZONE TIPS AND UPDATES", color = Color.White, fontFamily = Cond,
                    fontWeight = FontWeight.Black, fontSize = 22.sp)
                Spacer(Modifier.height(6.dp))
                Box(Modifier.width(56.dp).height(3.dp).background(Yellow))
            }
            Text("REFRESH", color = Yellow, fontFamily = Cond, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp,
                modifier = Modifier.clip(CutSmall).clickable {
                    tick(true)
                    scope.launch {
                        msg = try {
                            withContext(Dispatchers.IO) {
                                val t = Feed.download(); Feed.parse(t)
                                ctx.getSharedPreferences("mw4", 0).edit().putString("feed", t).apply()
                            }
                            tips = Feed.load(ctx)
                            WorkManager.getInstance(ctx).enqueue(OneTimeWorkRequestBuilder<UpdateWorker>().build())
                            "UPDATED"
                        } catch (e: Exception) { "Couldn't update: " + (e.message ?: e.javaClass.simpleName) }
                    }
                }.padding(12.dp))
        }
        Row(Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            cats.forEach { c ->
                val sel = c == filter
                val bg by animateColorAsState(if (sel) Yellow else Panel2, label = "chip")
                Box(Modifier.clip(CutSmall).background(bg).clickable { tick(false); filter = c }
                    .padding(horizontal = 14.dp, vertical = 8.dp)) {
                    Text(c, color = if (sel) Color.Black else Color.White, fontFamily = Cond,
                        fontWeight = FontWeight.Bold, fontSize = 12.sp, letterSpacing = 1.sp)
                }
            }
        }
        LazyColumn(contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 24.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)) {
            if (msg.isNotEmpty()) item { Text(msg, color = Muted, fontSize = 12.sp) }
            items(shown, key = { it.id }) { t -> TipCard(t) }
            item {
                Text("Disclaimer: All content is in English. Tips are summarised from top Warzone creators, pro players and official updates, and settings can change with game updates.",
                    color = Muted, fontSize = 11.sp, lineHeight = 16.sp)
            }
        }
    }
}
