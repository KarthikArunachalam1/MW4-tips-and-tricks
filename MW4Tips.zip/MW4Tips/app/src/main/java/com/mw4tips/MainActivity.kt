package com.mw4tips

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.work.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.concurrent.TimeUnit

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        val req = PeriodicWorkRequestBuilder<UpdateWorker>(6, TimeUnit.HOURS)
            .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build()).build()
        WorkManager.getInstance(this).enqueueUniquePeriodicWork("feed", ExistingPeriodicWorkPolicy.KEEP, req)
        setContent { MaterialTheme { Screen() } }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun Screen() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var tips by remember { mutableStateOf(Feed.load(ctx)) }
    var msg by remember { mutableStateOf("") }
    Scaffold(topBar = { TopAppBar(title = { Text("MW4 Competitive Tips") }, actions = {
        TextButton(onClick = { scope.launch {
            msg = try {
                withContext(Dispatchers.IO) {
                    val t = Feed.download(); Feed.parse(t)
                    ctx.getSharedPreferences("mw4", 0).edit().putString("feed", t).apply()
                }
                tips = Feed.load(ctx); "Updated"
            } catch (e: Exception) { "Couldn't update. Check FEED_URL and internet." }
        } }) { Text("Refresh") } }) }) { pad ->
        LazyColumn(Modifier.padding(pad).padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            if (msg.isNotEmpty()) item { Text(msg) }
            items(tips) { t ->
                Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(14.dp)) {
                    Text(t.category + if (t.advantage) "  •  COMPETITIVE EDGE" else "", style = MaterialTheme.typography.labelSmall)
                    Text(t.title, style = MaterialTheme.typography.titleMedium)
                    Spacer(Modifier.height(4.dp)); Text(t.body)
                    if (t.video.isNotBlank()) TextButton(onClick = {
                        ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(t.video)))
                    }) { Text("Watch video") }
                } }
            }
        }
    }
}
