package com.mw4tips

import android.content.Context
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

// TODO: host assets/feed.json somewhere public (e.g. GitHub raw URL) and paste the link here.
const val FEED_URL = "https://raw.githubusercontent.com/KarthikArunachalam1/MW4-tips-and-tricks/main/feed.json"
// TODO: optional. Google Apps Script web app URL that sends the email (see README.md).
const val WEBHOOK_URL = ""

data class Tip(val id: String, val title: String, val body: String,
               val category: String, val advantage: Boolean, val video: String)

object Feed {
    fun download(): String {
        val c = URL(FEED_URL).openConnection() as HttpURLConnection
        c.connectTimeout = 10000; c.readTimeout = 10000
        return c.inputStream.bufferedReader().use { it.readText() }
    }

    fun parse(txt: String): List<Tip> {
        val a = JSONObject(txt).getJSONArray("tips")
        return (0 until a.length()).map {
            val o = a.getJSONObject(it)
            Tip(o.getString("id"), o.getString("title"), o.getString("body"),
                o.optString("category", "General"), o.optBoolean("advantage", false), o.optString("video", ""))
        }
    }

    // Cached feed if we have one, otherwise the bundled feed.json
    fun load(ctx: Context): List<Tip> {
        val cached = ctx.getSharedPreferences("mw4", 0).getString("feed", null)
        val txt = cached ?: ctx.assets.open("feed.json").bufferedReader().use { it.readText() }
        return parse(txt)
    }
}
