package com.mw4tips

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

class UpdateWorker(private val ctx: Context, p: WorkerParameters) : CoroutineWorker(ctx, p) {
    override suspend fun doWork(): Result = try {
        val txt = Feed.download()
        val tips = Feed.parse(txt)
        val prefs = ctx.getSharedPreferences("mw4", 0)
        val seen = prefs.getStringSet("seen", null)
        prefs.edit().putString("feed", txt).putStringSet("seen", tips.map { it.id }.toSet()).apply()
        // First run only records what exists, so you aren't flooded with alerts.
        val fresh = if (seen == null) emptyList() else tips.filter { it.id !in seen && it.advantage }
        fresh.forEach { notifyTip(it); sendEmail(it) }
        Result.success()
    } catch (e: Exception) { Result.retry() }

    private fun notifyTip(t: Tip) {
        val nm = ctx.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("edge", "Competitive edge", NotificationManager.IMPORTANCE_HIGH))
        val n = NotificationCompat.Builder(ctx, "edge")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("New edge: " + t.title)
            .setContentText(t.body)
            .setStyle(NotificationCompat.BigTextStyle().bigText(t.body))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true).build()
        try { if (NotificationManagerCompat.from(ctx).areNotificationsEnabled())
            NotificationManagerCompat.from(ctx).notify(t.id.hashCode(), n) } catch (e: SecurityException) {}
    }

    private fun sendEmail(t: Tip) {
        val to = ctx.getSharedPreferences("mw4", 0).getString("email", "") ?: ""
        if (WEBHOOK_URL.isBlank() || to.isBlank()) return
        try {
            val c = URL(WEBHOOK_URL).openConnection() as HttpURLConnection
            c.requestMethod = "POST"; c.doOutput = true
            c.setRequestProperty("Content-Type", "application/json")
            val body = JSONObject().put("to", to).put("subject", "MW4 edge: " + t.title)
                .put("body", t.body + "\n\nVideo: " + t.video).toString()
            c.outputStream.use { it.write(body.toByteArray()) }
            c.responseCode
        } catch (e: Exception) {}
    }
}
